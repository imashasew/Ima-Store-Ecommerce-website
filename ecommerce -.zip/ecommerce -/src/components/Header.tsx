import { useState } from "react";
import { Link } from "react-router-dom";

export function Header({ cartItemCount, user, onLogout, onCartClick, onLoginClick, onSignupClick }) {
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <header className="fixed top-0 w-full shadow-md p-4 flex justify-between items-center" style={{ backgroundColor: 'grey' }}>
   
    <Link to="/" className="text-xl font-bold">Ima Shop</Link>

      <div className="flex items-center space-x-6">
        {/* Cart Button */}
        <button onClick={onCartClick} className="relative">
          🛒 <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full px-2">{cartItemCount}</span>
        </button>

        {/* If Logged In, Show Profile Dropdown */}
        {user ? (
          <div className="relative">
            <button onClick={() => setIsProfileOpen(!isProfileOpen)} className="bg-gray-200 px-3 py-1 rounded">
              {user.name} ⬇
            </button>

            {isProfileOpen && (
              <div className="absolute right-0 mt-2 bg-white shadow-lg rounded p-2">
                <button className="block px-4 py-2 hover:bg-gray-100">Profile</button>
                <button onClick={onLogout} className="block px-4 py-2 text-red-600 hover:bg-gray-100">Logout</button>
              </div>
            )}
          </div>
        ) : (
          <>
            <button onClick={onLoginClick} className="px-4 py-1 bg-blue-500 text-white rounded">Login</button>
            <button onClick={onSignupClick} className="px-4 py-1 bg-green-500 text-white rounded">Signup</button>
          </>
        )}
      </div>
    </header>
  );
}
